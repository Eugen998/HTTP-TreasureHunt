#include <stdio.h>      /* printf, sprintf */
#include <stdlib.h>     /* exit, atoi, malloc, free */
#include <unistd.h>     /* read, write, close */
#include <string.h>     /* memcpy, memset */
#include <sys/socket.h> /* socket, connect */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <netdb.h>      /* struct hostent, gethostbyname */
#include <arpa/inet.h>
#include "helpers.h"
#include "requests.h"
#include "parson.c"
#include "parson.h"

int main(int argc, char *argv[])
{
    int sockfd;


    /*
    *   Ex 0: Get cs.curs.pub.ro
    *
    *   Pas 1: Se deschide conexiunea (open_connection)
    *   Pas 2: Se creaza mesajul de request (compute_get_request)
    *   Pas 3: Se trimite la server mesajul (send_to_server)
    *   Pas 4: Se primeste raspuns de la server (receive_from_server)
    *   Pas 5: Se inchide conexiunea cu serverul (close_connection)
    */

    char s[BUFLEN];
    char enunt[BUFLEN];

    sockfd = open_connection("185.118.200.35", 8081, AF_INET, SOCK_STREAM, 0);
    send_to_server(sockfd, compute_get_request("185.118.200.35", "/task1/start", NULL));

    strcpy(s, receive_from_server(sockfd));
    strcpy(enunt, strchr(s,'{'));
    printf("%s\n", enunt);

    close_connection(sockfd);


    return 0;
}
